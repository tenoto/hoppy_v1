def baka():
	print("baka")