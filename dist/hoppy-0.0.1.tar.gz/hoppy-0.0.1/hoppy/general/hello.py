def hello_world():
	text = "hello world!"
	return text